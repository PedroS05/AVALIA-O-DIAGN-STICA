function publicar() {
  const input = document.getElementById('postInput');
  const texto = input.value.trim();
  if (!texto) return;

  const feedList = document.getElementById('feedList');

  const empty = feedList.querySelector('.empty-feed');
  if (empty) empty.remove();

  const agora = new Date().toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const card = document.createElement('div');
  card.className = 'post-card';
  card.innerHTML = `
    <div>${texto}</div>
    <div class="post-time">Agora • ${agora}</div>
  `;

  feedList.prepend(card);
  input.value = '';
  input.focus();
}

document.getElementById('btnPost').addEventListener('click', publicar);

document.getElementById('postInput').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') publicar();
});

document.getElementById('btnEdit').addEventListener('click', function() {
  alert('Editar Perfil');
});